# Claude API backend (starter)

A minimal Node/Express server that adds a Claude-powered endpoint to your
website or app. Your frontend (web or mobile) calls **your** server, and
your server calls Claude -- so your API key never reaches the browser.

## Setup

```bash
npm install
cp .env.example .env
# then paste your key from https://console.anthropic.com/settings/keys into .env
npm start
```

Open http://localhost:3000 to try the included demo page, or call the
endpoint directly:

```bash
curl -X POST http://localhost:3000/api/ask \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Explain photosynthesis in one sentence."}'
```

## Wiring it into your real app

- **Website**: point any frontend `fetch('/api/ask', ...)` call at this
  endpoint (same shape as the demo page).
- **Mobile app**: call the same endpoint over HTTPS from your app's
  networking code (Swift, Kotlin, React Native, etc.) -- it's just a
  normal JSON POST request.
- **Deploying**: put this behind HTTPS (Render, Fly.io, Railway, a VPS,
  etc.), set `ANTHROPIC_API_KEY` as an environment variable on the host
  (don't commit `.env`), and lock down the `cors()` call in `server.js`
  to only your real site's domain instead of allowing everyone.

## Notes

- Model used: `claude-sonnet-4-6`. Swap it in `server.js` for a faster/
  cheaper or more capable model as needed.
- This has no auth on `/api/ask` -- anyone who finds the URL can spend
  your API credits. Add your own auth (API key, session check, rate
  limiting) before shipping this publicly.
- For streaming responses (so text appears as it's generated), the
  Anthropic SDK supports `anthropic.messages.stream(...)` -- ask if you
  want that version.
