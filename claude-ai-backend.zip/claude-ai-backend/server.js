// server.js
// A minimal backend that adds a Claude-powered endpoint to a website or app.
// Your frontend never sees the API key -- it only talks to this server.

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import Anthropic from '@anthropic-ai/sdk';

const app = express();
app.use(cors());               // restrict this in production, see note below
app.use(express.json());
app.use(express.static('public')); // serves the demo page in /public

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY, // read from .env, never hardcoded
});

// POST /api/ask
// body: { prompt: string }
// returns: { reply: string }
app.post('/api/ask', async (req, res) => {
  const { prompt } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Missing "prompt" string in request body.' });
  }

  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1024,
      messages: [
        { role: 'user', content: prompt },
      ],
    });

    // message.content is an array of blocks (usually one text block)
    const reply = message.content
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('\n');

    res.json({ reply });
  } catch (err) {
    console.error('Claude API error:', err);
    res.status(500).json({ error: 'Something went wrong talking to Claude.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
